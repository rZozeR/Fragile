﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameGod : MonoBehaviour
{
    public GameObject ragdoll, e_ragdoll, player, enemies, enemy, painter, spawn_effect;

    public GameObject platform_ui;

    public Text txt_player_rank;

    public Transform cam_pos, fin_lines;

    private Transform cam_control;

    private void Start()
    {
        cam_control = Camera.main.transform.parent;
        
        StartCoroutine(Spawn_Enemy(10, 0f));
    }

    public void Destroy_Object(Transform pos, bool type)
    {
        if (type)
        {
            Destroy(Instantiate(ragdoll, pos.position, pos.rotation), 1.5f);
            StartCoroutine(Spawn_Player());
        }
        else
        {
            Destroy(Instantiate(e_ragdoll, pos.position, pos.rotation), 1.5f);
            StartCoroutine(Spawn_Enemy(1, 2f));
        }

        Destroy(pos.gameObject);
    }

    public void Display_Rank(string rank)
    {
        txt_player_rank.text = rank;
    }

    private Vector3 Check_Position()
    {
        Vector3 pos = new Vector3(Random.Range(-5f, 5f), 1f, Random.Range(-3f, 3f));
        Collider[] intersecting = Physics.OverlapSphere(pos, 0.4f);

        while (intersecting.Length != 0)
        {
            pos = new Vector3(Random.Range(-5f, 5f), 1f, Random.Range(-3f, 3f));
            intersecting = Physics.OverlapSphere(pos, 0.4f);
        }

        Instantiate(spawn_effect, pos + Vector3.down, spawn_effect.transform.rotation);
        return pos;
    }

    IEnumerator Spawn_Enemy(int amount, float cooldown)
    {
        yield return new WaitForSeconds(cooldown);

        for (int i = 0; i < amount; i++)
        {
            Instantiate(enemy, Check_Position(), Quaternion.identity, enemies.transform).GetComponent<Enemy>().lines = fin_lines;
        }
    }

    IEnumerator Spawn_Player()
    {
        yield return new WaitForSeconds(2f);
        Instantiate(player, Check_Position(), Quaternion.identity);
    }

    IEnumerator Move_Camera()
    {
        for (int i = 0; i < 100; i++)
        {
            yield return new WaitForSeconds(0.01f);
            cam_control.position = Vector3.MoveTowards(cam_control.position, cam_pos.position + (Vector3.forward * 6), 0.2f);
        }
        painter.SetActive(true);
    }

    private void OnTriggerEnter(Collider col)
    {
        if (col.tag == "Enemy")
        {
            Destroy(Instantiate(ragdoll, col.transform.position, col.transform.rotation), 1.5f);
            col.gameObject.SetActive(false);
        }
        else if (col.tag == "Player")
        {
            Destroy(Instantiate(ragdoll, col.transform.position, col.transform.rotation), 1.5f);
            Destroy(col.gameObject);
            
            platform_ui.SetActive(false);
            StartCoroutine(Move_Camera());
        }
    }
}
