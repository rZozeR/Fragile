﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuGod : MonoBehaviour
{
    public void Change_Scene(string named)
    {
        SceneManager.LoadScene(named);
    }
}
