﻿using UnityEngine;

public class PlatformMove : MonoBehaviour
{
    public Transform platform;

    public float speed = 5f;

    private Vector3 target_1, target_2, dir;

    void Start()
    {
        target_1 = transform.GetChild(0).position;
        target_2 = transform.GetChild(1).position;

        dir = (Random.Range(0, 2) == 0) ? dir = target_1 : dir = target_2;
    }

    void Update()
    {
        platform.position = Vector3.MoveTowards(platform.position, dir, speed * Time.deltaTime);

        if (Vector3.Distance(platform.position, dir) <= 0.5f)
            dir = (dir == target_1) ? dir = target_2 : dir = target_1;
    }
}
