﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ragdoll : MonoBehaviour
{
    public GameObject glass_effect;

    private Rigidbody rg3d;

    private bool on = false;

    private void Start()
    {
        rg3d = GetComponent<Rigidbody>();
        rg3d.velocity = Player.player_dir * 5;
        rg3d.angularVelocity += new Vector3(Random.Range(-90, 90), Random.Range(-90, 90), Random.Range(-90, 90));
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (!on && collision.gameObject.tag != "Player")
        {
            on = true;
            Instantiate(glass_effect, transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
    }
}
