﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Enemy : MonoBehaviour
{
    public Transform lines;

    private NavMeshAgent agent;

    private GameGod game_god;

    private Rigidbody rg3d;
    
    private Vector3 offset;

    private int current_line = 0;

    private bool error_margin = false;

    private void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        rg3d = GetComponent<Rigidbody>();
        game_god = GameObject.FindGameObjectWithTag("GGod").GetComponent<GameGod>();

        offset = new Vector3(Random.Range(-4f, 4f), 0, 0);

        if (lines == null)
            game_god.Destroy_Object(transform, false);
        
        agent.destination = lines.GetChild(current_line).position;
        agent.speed = Random.Range(4.5f, 5.5f);
    }

    private void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.tag == "Dangerous")
        {
            game_god.Destroy_Object(transform, false);
            gameObject.SetActive(false);
            Destroy(gameObject, 2f);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Dangerous")
        {
            game_god.Destroy_Object(transform, false);
        }
        else if (other.tag == "Line" && !error_margin)
        {
            error_margin = true;
            
            if (current_line < lines.childCount - 1)
            {
                current_line++;
                agent.destination = lines.GetChild(current_line).position;
            }
            else
                agent.destination = game_god.transform.GetChild(1).position + offset;

            StartCoroutine(Reset_Margin());
        }
    }

    IEnumerator Reset_Margin()
    {
        yield return new WaitForSeconds(1f);
        error_margin = false;
    }
}
