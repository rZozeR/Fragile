﻿using System.Collections;
using UnityEngine;

public class PlatformTimer : MonoBehaviour
{
    public Transform platform;

    public float cooldown = 3f;

    private Vector3 target_1, target_2, dir;

    private bool move = false;

    void Start()
    {
        target_1 = transform.GetChild(0).position;
        target_2 = transform.GetChild(1).position;
        dir = target_2;
        StartCoroutine(Move_Timer(cooldown));
    }

    void Update()
    {
        if (move)
        {
            platform.position = Vector3.MoveTowards(platform.position, dir, 4 * Time.deltaTime);

            if (Vector3.Distance(platform.position, dir) <= 0.05f)
                StartCoroutine(Move_Timer(cooldown));
        }
    }

    IEnumerator Move_Timer(float duration)
    {
        move = false;
        yield return new WaitForSeconds(duration);

        dir = (dir == target_1) ? dir = target_2 : dir = target_1;
        move = true;
    }
}
