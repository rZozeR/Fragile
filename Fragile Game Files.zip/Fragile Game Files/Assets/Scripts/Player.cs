﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public static Vector3 player_dir;

    private Transform enemy, force_pos;

    private GameObject cam;

    private Animator anim;

    private GameGod game_god;

    private Rigidbody rg3d;

    public float speed = 5f;

    private float x_input = 0, z_input = 0, rotation_speed = 0, temp;

    private int rank = 0;

    private Vector3 input_rot, dir;
    
    void Start()
    {
        rg3d = GetComponent<Rigidbody>();
        anim = GetComponent<Animator>();
        cam = Camera.main.transform.parent.gameObject;
        force_pos = transform.GetChild(0);

        game_god = GameObject.FindGameObjectWithTag("GGod").GetComponent<GameGod>();
        enemy = GameObject.FindGameObjectWithTag("Enemy").transform;
        
        InvokeRepeating(nameof(Calculate_Rank), 0, 0.5f);
    }

    private void Update()
    {
        x_input = Input.GetAxis("Horizontal");
        z_input = Input.GetAxis("Vertical");

        if (transform.position.y <= -5)
            Destroy_Player();

        cam.transform.position = Vector3.forward * transform.position.z;

        Display_Animation();
    }

    private void Display_Animation()
    {
        anim.speed = (x_input == 0 && z_input == 0) ? anim.speed = 0 : anim.speed = 1;

        if (z_input >= 0)
            input_rot = new Vector3(x_input, z_input / 2.5f, 1.0f);
        else
            input_rot = new Vector3(-x_input, z_input / 5, 1.0f);

        Quaternion final_rotation = Quaternion.LookRotation(input_rot);

        transform.rotation = Quaternion.Slerp(transform.rotation, final_rotation, speed * Time.deltaTime);
    }

    private void FixedUpdate()
    {
        Movement();
    }

    private void Movement()
    {
        dir = new Vector3(x_input, 0, z_input);
        Vector3 velocityChange = (dir * speed - rg3d.velocity);

        velocityChange.x = Mathf.Clamp(velocityChange.x, -10, 10);
        velocityChange.y = 0;
        velocityChange.z = Mathf.Clamp(velocityChange.z, -10, 10);
        
        rg3d.AddForce(velocityChange, ForceMode.VelocityChange);
    }

    private void Calculate_Rank()
    {
        rank = 1;
        for (int i = 0; i < enemy.childCount; i++)
        {
            if (transform.position.z < enemy.GetChild(i).position.z)
                rank++;
        }
        game_god.Display_Rank(rank.ToString());
    }

    private void Destroy_Player()
    {
        player_dir = dir;
        game_god.Destroy_Object(transform, true);
        gameObject.SetActive(false);
        Destroy(gameObject, 2f);
    }

    private void Rotational_Force()
    {
        rg3d.AddForceAtPosition(Vector3.right * -rotation_speed, force_pos.position, ForceMode.Acceleration);
    }

    private void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.tag == "Dangerous")
            Destroy_Player();
        else if (col.gameObject.tag == "Rotating")
        {
            rotation_speed = col.gameObject.GetComponent<PlatformRotate>().rot.z * 2;
            InvokeRepeating(nameof(Rotational_Force), 0, 0.01f);
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.tag == "Rotating")
            CancelInvoke(nameof(Rotational_Force));
    }
}
