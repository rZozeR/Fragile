namespace UnityEditor.ShaderGraph
{
    enum PreviewMode
    {
        Preview2D,
        Preview3D,
        Wireframe
    }
}
