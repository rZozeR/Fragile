# Master Nodes

| [PBR Master](PBR-Master-Node.md) | [Unlit Master](Unlit-Master-Node.md) |
|:-------------|:------|
| ![Image](images/PBRMasterNodeThumb.png) | ![Image](images/UnlitMasterNodeThumb.png) |
| Master Node for physically based rendering. | Master Node for unlit materials. |

